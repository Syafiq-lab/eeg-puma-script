package com.accenture.inventory_management.service;

import com.accenture.inventory_management.dto.ProductRequest;
import com.accenture.inventory_management.entity.Category;
import com.accenture.inventory_management.entity.Product;
import com.accenture.inventory_management.entity.Supplier;
import com.accenture.inventory_management.repository.CategoryRepository;
import com.accenture.inventory_management.repository.ProductRepository;
import com.accenture.inventory_management.repository.SupplierRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class ProductServiceTest {

    private ProductServiceImpl productService;

    @Mock
    private ProductRepository productRepo;

    @Mock
    private CategoryRepository categoryRepo;

    @Mock
    private SupplierRepository supplierRepo;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        productService = new ProductServiceImpl(productRepo, categoryRepo, supplierRepo);
    }

    private Category sampleCategory() {
        return new Category(1L, "Bakery", "Bakery items");
    }

    private Supplier sampleSupplier() {
        return new Supplier(1L, "Sweet Supplier", "Ali", "ali@example.com", "123456");
    }

    private ProductRequest sampleRequest() {
        ProductRequest request = new ProductRequest();
        request.setName("Cream Puff");
        request.setSku("CP-001");
        request.setUnitPrice(BigDecimal.valueOf(5.0));
        request.setCurrentStock(100);
        request.setReorderLevel(10);
        request.setCategoryId(1L);
        request.setSupplierId(1L);
        return request;
    }

    private Product sampleProduct() {
        Product product = new Product();
        product.setProductId(1L);
        product.setName("Cream Puff");
        product.setSku("CP-001");
        product.setUnitPrice(BigDecimal.valueOf(5.0));
        product.setCurrentStock(100);
        product.setReorderLevel(10);
        product.setCategory(sampleCategory());
        product.setSupplier(sampleSupplier());
        return product;
    }

    @Test
    void testCreateProduct() {
        ProductRequest request = sampleRequest();
        Product savedProduct = sampleProduct();

        when(categoryRepo.findById(1L)).thenReturn(Optional.of(sampleCategory()));
        when(supplierRepo.findById(1L)).thenReturn(Optional.of(sampleSupplier()));
        when(productRepo.save(any(Product.class))).thenReturn(savedProduct);

        Product result = productService.create(request);

        assertEquals("Cream Puff", result.getName());
        assertEquals("CP-001", result.getSku());
    }

    @Test
    void testCreateProduct_CategoryNotFound() {
        ProductRequest request = sampleRequest();
        when(categoryRepo.existsById(1L)).thenReturn(false);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> productService.create(request));
        assertEquals("Category not found with ID: 1", exception.getMessage());
    }

    @Test
    void testCreateProduct_SupplierNotFound() {
        ProductRequest request = sampleRequest();
        when(categoryRepo.findById(1L)).thenReturn(Optional.of(sampleCategory()));
        when(supplierRepo.existsById(1L)).thenReturn(false);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> productService.create(request));
        assertEquals("Supplier not found with ID: 1", exception.getMessage());
    }

    @Test
    void testGetById() {
        when(productRepo.findById(1L)).thenReturn(Optional.of(sampleProduct()));

        Product result = productService.getById(1L);

        assertEquals("Cream Puff", result.getName());
    }

    @Test
    void testGetById_NotFound() {
        when(productRepo.findById(1L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> productService.getById(1L));
        assertEquals("Product not found with ID: 1", exception.getMessage());
    }

    @Test
    void testUpdateProduct() {
        ProductRequest request = sampleRequest();
        request.setName("Updated Cream Puff");
        Product existing = sampleProduct();

        when(productRepo.findById(1L)).thenReturn(Optional.of(existing));
        when(categoryRepo.findById(1L)).thenReturn(Optional.of(sampleCategory()));
        when(supplierRepo.findById(1L)).thenReturn(Optional.of(sampleSupplier()));
        when(productRepo.save(any(Product.class))).thenReturn(existing);

        Product result = productService.update(1L, request);

        assertEquals("Updated Cream Puff", result.getName());
    }

    @Test
    void testDeleteProduct() {
        Product existing = sampleProduct();
        when(productRepo.findById(1L)).thenReturn(Optional.of(existing));
        doNothing().when(productRepo).delete(existing);

        productService.delete(1L);
        verify(productRepo, times(1)).delete(existing);
    }

    @Test
    void testSearchByName() {
        when(productRepo.findByNameContainingIgnoreCase("Cream")).thenReturn(Arrays.asList(sampleProduct()));

        List<Product> result = productService.searchByName("Cream");
        assertEquals(1, result.size());
    }

    @Test
    void testGetByCategory() {
        when(productRepo.findByCategoryId(1L)).thenReturn(Arrays.asList(sampleProduct()));

        List<Product> result = productService.getByCategory(1L);
        assertEquals(1, result.size());
    }

    @Test
    void testGetBySupplier() {
        when(productRepo.findBySupplierId(1L)).thenReturn(Arrays.asList(sampleProduct()));

        List<Product> result = productService.getBySupplier(1L);
        assertEquals(1, result.size());
    }

    @Test
    void testFindLowStock() {
        when(productRepo.findByCurrentStockLessThanEqual(50)).thenReturn(Arrays.asList(sampleProduct()));

        List<Product> result = productService.findLowStock();
        assertEquals(1, result.size());
    }
}
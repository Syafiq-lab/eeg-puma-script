package com.accenture.inventory_management.service;

import com.accenture.inventory_management.entity.InventoryTransaction;
import com.accenture.inventory_management.entity.Product;
import com.accenture.inventory_management.repository.InventoryTransactionRepository;
import com.accenture.inventory_management.repository.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class InventoryTransactionServiceTest {

    @Mock
    private ProductRepository productRepo;

    @Mock
    private InventoryTransactionRepository transactionRepo;

    @InjectMocks
    private InventoryTransactionImpl inventoryTransactionService;

    private Product product;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        product = new Product();
        product.setProductId(1L);
        product.setName("Croissant");
        product.setCurrentStock(10);
    }

    @Test
    void testStockIn_Success() {
        when(productRepo.findById(1L)).thenReturn(Optional.of(product));
        when(productRepo.save(any(Product.class))).thenReturn(product);
        when(transactionRepo.save(any(InventoryTransaction.class)))
                .thenAnswer(inv -> inv.getArgument(0));

        InventoryTransaction tx = inventoryTransactionService.stockIn(1L, 5);

        assertNotNull(tx);
        assertEquals("IN", tx.getTransactionType());
        assertEquals(15, product.getCurrentStock());
        assertEquals(5, tx.getQuantity());
        verify(productRepo).save(product);
        verify(transactionRepo).save(any(InventoryTransaction.class));
    }

    @Test
    void testStockIn_InvalidQuantity_ThrowsException() {
        assertThrows(IllegalArgumentException.class,
                () -> inventoryTransactionService.stockIn(1L, 0));
    }

    @Test
    void testStockOut_Success() {
        when(productRepo.findById(1L)).thenReturn(Optional.of(product));
        when(productRepo.save(any(Product.class))).thenReturn(product);
        when(transactionRepo.save(any(InventoryTransaction.class)))
                .thenAnswer(inv -> inv.getArgument(0));

        InventoryTransaction tx = inventoryTransactionService.stockOut(1L, 5);

        assertNotNull(tx);
        assertEquals("OUT", tx.getTransactionType());
        assertEquals(5, product.getCurrentStock());
        assertEquals(5, tx.getQuantity());
        verify(productRepo).save(product);
        verify(transactionRepo).save(any(InventoryTransaction.class));
    }

    @Test
    void testStockOut_InsufficientStock_ThrowsException() {
        product.setCurrentStock(2);
        when(productRepo.findById(1L)).thenReturn(Optional.of(product));

        assertThrows(RuntimeException.class,
                () -> inventoryTransactionService.stockOut(1L, 5));
    }

    @Test
    void testGetAllTransactions() {
        InventoryTransaction tx1 = new InventoryTransaction(1L, product, "IN", 5, LocalDateTime.now());
        InventoryTransaction tx2 = new InventoryTransaction(2L, product, "OUT", 3, LocalDateTime.now());

        when(transactionRepo.findAll()).thenReturn(Arrays.asList(tx1, tx2));

        List<InventoryTransaction> transactions = inventoryTransactionService.getAll();

        assertEquals(2, transactions.size());
        verify(transactionRepo).findAll();
    }

    @Test
    void testGetByProduct() {
        InventoryTransaction tx = new InventoryTransaction(1L, product, "IN", 5, LocalDateTime.now());

        when(transactionRepo.findByProductProductId(1L)).thenReturn(List.of(tx));

        List<InventoryTransaction> transactions = inventoryTransactionService.getByProduct(1L);

        assertEquals(1, transactions.size());
        assertEquals("IN", transactions.get(0).getTransactionType());
        verify(transactionRepo).findByProductProductId(1L);
    }
}

package com.accenture.inventory_management.integration;

import com.accenture.inventory_management.entity.Product;
import com.accenture.inventory_management.repository.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class InventoryIntegrationTest {

    @Autowired
    private ProductRepository productRepository;

    @BeforeEach
    void cleanDb() {
        productRepository.deleteAll(); // reset DB before each test
    }

    @Test
    void shouldCreateAndReadProduct() {
        // Arrange
        Product product = new Product();
        product.setName("Laptop");
        product.setSku("LAP001");
        product.setUnitPrice(BigDecimal.valueOf(3500.00));
        product.setCurrentStock(10);
        product.setReorderLevel(2);

        // Act
        Product saved = productRepository.save(product);
        Product found = productRepository.findById(saved.getProductId()).orElseThrow();

        // Assert
        assertThat(found.getName()).isEqualTo("Laptop");
        assertThat(found.getSku()).isEqualTo("LAP001");
        assertThat(found.getUnitPrice()).isEqualByComparingTo("3500.00");
        assertThat(found.getCurrentStock()).isEqualTo(10);
    }

    @Test
    void shouldUpdateProduct() {
        // Arrange
        Product product = new Product();
        product.setName("Mouse");
        product.setSku("MOU001");
        product.setUnitPrice(BigDecimal.valueOf(50.00));
        product.setCurrentStock(100);
        product.setReorderLevel(10);
        Product saved = productRepository.save(product);

        // Act
        saved.setUnitPrice(BigDecimal.valueOf(45.00));
        saved.setCurrentStock(80);
        Product updated = productRepository.save(saved);

        // Assert
        assertThat(updated.getUnitPrice()).isEqualByComparingTo("45.00");
        assertThat(updated.getCurrentStock()).isEqualTo(80);
    }

    @Test
    void shouldDeleteProduct() {
        // Arrange
        Product product = new Product();
        product.setName("Keyboard");
        product.setSku("KEY001");
        product.setUnitPrice(BigDecimal.valueOf(150.00));
        product.setCurrentStock(20);
        product.setReorderLevel(5);
        Product saved = productRepository.save(product);

        // Act
        productRepository.deleteById(saved.getProductId());

        // Assert
        boolean exists = productRepository.existsById(saved.getProductId());
        assertThat(exists).isFalse();
    }

    @Test
    void shouldFindProductsByNameContainingIgnoreCase() {
        // Arrange
        Product p1 = new Product();
        p1.setName("Gaming Laptop");
        p1.setSku("LAP001");
        p1.setUnitPrice(BigDecimal.valueOf(4000.00));
        p1.setCurrentStock(5);
        p1.setReorderLevel(2);
        productRepository.save(p1);

        Product p2 = new Product();
        p2.setName("Office Laptop");
        p2.setSku("LAP002");
        p2.setUnitPrice(BigDecimal.valueOf(2500.00));
        p2.setCurrentStock(10);
        p2.setReorderLevel(3);
        productRepository.save(p2);

        // Act
        List<Product> found = productRepository.findByNameContainingIgnoreCase("laptop");

        // Assert
        assertThat(found).hasSize(2);
        assertThat(found).extracting(Product::getName)
                .containsExactlyInAnyOrder("Gaming Laptop", "Office Laptop");
    }

    @Test
    void shouldFindLowStockProducts() {
        // Arrange
        Product p1 = new Product();
        p1.setName("USB Cable");
        p1.setSku("USB001");
        p1.setUnitPrice(BigDecimal.valueOf(10.00));
        p1.setCurrentStock(2);
        p1.setReorderLevel(5);
        productRepository.save(p1);

        Product p2 = new Product();
        p2.setName("HDMI Cable");
        p2.setSku("HDMI001");
        p2.setUnitPrice(BigDecimal.valueOf(20.00));
        p2.setCurrentStock(15);
        p2.setReorderLevel(5);
        productRepository.save(p2);

        // Act
        List<Product> lowStock = productRepository.findByCurrentStockLessThanEqual(5);

        // Assert
        assertThat(lowStock).hasSize(1);
        assertThat(lowStock.get(0).getName()).isEqualTo("USB Cable");
    }
}

package com.accenture.inventory_management.controller;

import com.accenture.inventory_management.entity.Category;
import com.accenture.inventory_management.service.CategoryService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

    @WebMvcTest(CategoryController.class)
    class CategoryControllerTest {

        @Autowired
        private MockMvc mockMvc;

        @MockBean
        private CategoryService categoryService;

        @Autowired
        private ObjectMapper objectMapper;

        private Category category1;
        private Category category2;

        @BeforeEach
        void setUp() {
            category1 = new Category(1L, "Electronics", "Electronic items");
            category2 = new Category(2L, "Books", "All kinds of books");
        }

        @Test
        void testGetAllCategories() throws Exception {
            Mockito.when(categoryService.getAll()).thenReturn(Arrays.asList(category1, category2));

            mockMvc.perform(get("/api/category"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$", hasSize(2)))
                    .andExpect(jsonPath("$[0].name", is("Electronics")))
                    .andExpect(jsonPath("$[1].name", is("Books")));
        }

        @Test
        void testGetCategoryById() throws Exception {
            Mockito.when(categoryService.getById(1L)).thenReturn(category1);

            mockMvc.perform(get("/api/category/1"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.name", is("Electronics")))
                    .andExpect(jsonPath("$.description", is("Electronic items")));
        }

        @Test
        void testCreateCategory() throws Exception {
            Mockito.when(categoryService.saveCategory(any(Category.class))).thenReturn(category1);

            mockMvc.perform(post("/api/category")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(category1)))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.name", is("Electronics")));
        }

        @Test
        void testUpdateCategory() throws Exception {
            Category updatedCategory = new Category(1L, "Updated Electronics", "Updated description");
            Mockito.when(categoryService.update(eq(1L), any(Category.class)))
                    .thenReturn(updatedCategory);

            mockMvc.perform(put("/api/category/1")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(updatedCategory)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.name", is("Updated Electronics")))
                    .andExpect(jsonPath("$.description", is("Updated description")));
        }

        @Test
        void testDeleteCategory() throws Exception {
            Mockito.doNothing().when(categoryService).delete(1L);

            mockMvc.perform(delete("/api/category/1"))
                    .andExpect(status().isNoContent());
        }

        @Test
        void testSearchByName() throws Exception {
            List<Category> results = Arrays.asList(category1);
            Mockito.when(categoryService.searchByName("Electronics")).thenReturn(results);

            mockMvc.perform(get("/api/category/search")
                            .param("name", "Electronics"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$", hasSize(1)))
                    .andExpect(jsonPath("$[0].name", is("Electronics")));
        }


}

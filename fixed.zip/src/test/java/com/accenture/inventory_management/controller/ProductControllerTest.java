package com.accenture.inventory_management.controller;

import com.accenture.inventory_management.dto.ProductRequest;
import com.accenture.inventory_management.entity.Product;
import com.accenture.inventory_management.service.ProductService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ProductController.class)
class ProductControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProductService productService;

    @Autowired
    private ObjectMapper objectMapper;

    private Product sampleProduct() {
        Product product = new Product();
        product.setProductId(1L);
        product.setName("Laptop");
        product.setSku("SKU123");
        product.setUnitPrice(BigDecimal.valueOf(1500.00));
        product.setCurrentStock(20);
        product.setReorderLevel(5);
        return product;
    }

    private ProductRequest sampleRequest() {
        ProductRequest request = new ProductRequest();
        request.setName("Laptop");
        request.setSku("SKU123");
        request.setUnitPrice(BigDecimal.valueOf(1500.00));
        request.setCurrentStock(20);
        request.setReorderLevel(5);
        request.setCategoryId(1L);
        request.setSupplierId(1L);
        return request;
    }

    @Test
    void testCreateProduct() throws Exception {
        ProductRequest request = sampleRequest();
        Product product = sampleProduct();

        Mockito.when(productService.create(any(ProductRequest.class))).thenReturn(product);

        mockMvc.perform(post("/api/product")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.name").value("Laptop"))
                .andExpect(jsonPath("$.sku").value("SKU123"));
    }

    @Test
    void testGetAllProducts() throws Exception {
        List<Product> products = Arrays.asList(sampleProduct());
        Mockito.when(productService.getAll()).thenReturn(products);

        mockMvc.perform(get("/api/product"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Laptop"));
    }

    @Test
    void testGetById() throws Exception {
        Product product = sampleProduct();
        Mockito.when(productService.getById(1L)).thenReturn(product);

        mockMvc.perform(get("/api/product/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.sku").value("SKU123"));
    }

    @Test
    void testUpdateProduct() throws Exception {
        ProductRequest request = sampleRequest();
        request.setName("Updated Laptop");
        Product updated = sampleProduct();
        updated.setName("Updated Laptop");

        Mockito.when(productService.update(eq(1L), any(ProductRequest.class))).thenReturn(updated);

        mockMvc.perform(put("/api/product/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Updated Laptop"));
    }

    @Test
    void testDeleteProduct() throws Exception {
        Mockito.doNothing().when(productService).delete(1L);

        mockMvc.perform(delete("/api/product/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    void testSearchByName() throws Exception {
        Mockito.when(productService.searchByName("Laptop")).thenReturn(Arrays.asList(sampleProduct()));

        mockMvc.perform(get("/api/product/search").param("name", "Laptop"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].sku").value("SKU123"));
    }

    @Test
    void testGetLowStock() throws Exception {
        Mockito.when(productService.findLowStock()).thenReturn(Arrays.asList(sampleProduct()));

        mockMvc.perform(get("/api/product/low-stock"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Laptop"));
    }

    @Test
    void testGetByCategory() throws Exception {
        Mockito.when(productService.getByCategory(1L)).thenReturn(Arrays.asList(sampleProduct()));

        mockMvc.perform(get("/api/product/by-category/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Laptop"));
    }

    @Test
    void testGetBySupplier() throws Exception {
        Mockito.when(productService.getBySupplier(1L)).thenReturn(Arrays.asList(sampleProduct()));

        mockMvc.perform(get("/api/product/by-supplier/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].sku").value("SKU123"));
    }
}

package com.accenture.inventory_management.controller;

import com.accenture.inventory_management.entity.Supplier;
import com.accenture.inventory_management.service.SupplierService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(SupplierController.class)
class SupplierControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SupplierService supplierService;

    @Autowired
    private ObjectMapper objectMapper;

    private Supplier supplier1;
    private Supplier supplier2;

    @BeforeEach
    void setUp() {
        supplier1 = new Supplier(1L, "Tech Corp", "Alice", "alice@tech.com", "123456789");
        supplier2 = new Supplier(2L, "Book World", "Bob", "bob@book.com", "987654321");
    }

    @Test
    void testGetAllSuppliers() throws Exception {
        Mockito.when(supplierService.getAll()).thenReturn(Arrays.asList(supplier1, supplier2));

        mockMvc.perform(get("/api/supplier"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].companyName", is("Tech Corp")))
                .andExpect(jsonPath("$[1].companyName", is("Book World")));
    }

    @Test
    void testGetSupplierById() throws Exception {
        Mockito.when(supplierService.getById(1L)).thenReturn(supplier1);

        mockMvc.perform(get("/api/supplier/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.companyName", is("Tech Corp")))
                .andExpect(jsonPath("$.contactPerson", is("Alice")));
    }

    @Test
    void testCreateSupplier() throws Exception {
        Mockito.when(supplierService.create(any(Supplier.class))).thenReturn(supplier1);

        mockMvc.perform(post("/api/supplier")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(supplier1)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.companyName", is("Tech Corp")));
    }

    @Test
    void testUpdateSupplier() throws Exception {
        Supplier updatedSupplier = new Supplier(1L, "Updated Corp", "Charlie", "charlie@corp.com", "111222333");
        Mockito.when(supplierService.update(eq(1L), any(Supplier.class)))
                .thenReturn(updatedSupplier);

        mockMvc.perform(put("/api/supplier/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedSupplier)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.companyName", is("Updated Corp")))
                .andExpect(jsonPath("$.contactPerson", is("Charlie")));
    }

    @Test
    void testDeleteSupplier() throws Exception {
        Mockito.doNothing().when(supplierService).delete(1L);

        mockMvc.perform(delete("/api/supplier/1"))
                .andExpect(status().isNoContent());
    }
}

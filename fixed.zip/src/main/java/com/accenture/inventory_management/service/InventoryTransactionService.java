package com.accenture.inventory_management.service;


import com.accenture.inventory_management.entity.InventoryTransaction;

import java.util.List;

public interface InventoryTransactionService {
    InventoryTransaction stockIn(Long productId, int quantity);
    InventoryTransaction stockOut(Long productId, int quantity);

    List<InventoryTransaction> getAll();
    List<InventoryTransaction> getByProduct(Long productId);
}


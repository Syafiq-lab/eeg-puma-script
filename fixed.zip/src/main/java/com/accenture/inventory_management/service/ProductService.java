package com.accenture.inventory_management.service;

import com.accenture.inventory_management.dto.ProductRequest;
import com.accenture.inventory_management.entity.Product;

import java.util.List;

public interface ProductService {

    List<Product> getAll();
    Product getById(Long id);
    Product create(ProductRequest request);
    Product update(Long id, ProductRequest request);
    void delete(Long id);
    List<Product> searchByName(String name);
    List<Product> findLowStock();
    List<Product> getByCategory(Long categoryId);
    List<Product> getBySupplier(Long supplierId);
    List<Product> getLowStockProducts(int threshold);
}

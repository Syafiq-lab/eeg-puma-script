package com.accenture.inventory_management.repository;

import com.accenture.inventory_management.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    // Search by name (case-insensitive)
    List<Product> findByNameContainingIgnoreCase(String name);

    // Low stock detection (<= threshold)
    List<Product> findByCurrentStockLessThanEqual(Integer stock);

    // By category
    List<Product> findByCategoryId(Long categoryId);

    // By supplier
    List<Product> findBySupplierId(Long supplierId);

    // Exact match by name
    List<Product> findByName(String name);
}

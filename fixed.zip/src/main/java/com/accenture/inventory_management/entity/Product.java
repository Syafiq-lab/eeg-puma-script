package com.accenture.inventory_management.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Product")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long productId;

    @NotBlank(message = "Name is required")
    @Column(nullable = false, length = 50)
    private String name;

    @NotBlank(message = "sku is required")
    @Column(nullable = false, length = 30)
    private String sku;

    @ManyToOne //each product belongs to one category
    @JoinColumn(name = "category_id")
    private Category category;

    @ManyToOne//each product belongs to one supplier
    @JoinColumn(name = "supplier_id")
    private Supplier supplier;

    @Column(name = "unit_price", nullable = false)
    private BigDecimal unitPrice;

    @Column(name = "current_stock", nullable = false)
    private int currentStock;

    @Column(name = "reorder_level", nullable = false)
    private int reorderLevel;
}


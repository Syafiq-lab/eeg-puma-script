package com.accenture.inventory_management.controller;

import com.accenture.inventory_management.service.InventoryTransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/inventory")
public class InventoryTransactionController {

    @Autowired
    private InventoryTransactionService inventoryService;

    @PostMapping("/stockin/{productId}")
    public ResponseEntity<?> stockIn(@PathVariable Long productId, @RequestParam int quantity) {
        return ResponseEntity.ok(inventoryService.stockIn(productId, quantity));
    }

    @PostMapping("/stockout/{productId}")
    public ResponseEntity<?> stockOut(@PathVariable Long productId, @RequestParam int quantity) {
        return ResponseEntity.ok(inventoryService.stockOut(productId, quantity));
    }

    @GetMapping("/transactions")
    public ResponseEntity<?> getAllTransactions() {
        return ResponseEntity.ok(inventoryService.getAll());
    }

    @GetMapping("/transactions/{productId}")
    public ResponseEntity<?> getTransactionsByProduct(@PathVariable Long productId) {
        return ResponseEntity.ok(inventoryService.getByProduct(productId));
    }

}



package com.accenture.inventory_management.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
/*
id,
product_id,
transaction_type,
quantity,
transaction_date
 */

@Entity
@Table (name="inventory_transactions")
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor

public class InventoryTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne // Each transaction is linked to one product
    @JoinColumn(name = "product_id")
    private Product product;

    @Column(name = "transaction_type", nullable = false)
    private String transactionType; //"IN" for stockin, "OUT" for stockout

    private int quantity;

    @Column(name = "transaction_date", nullable = false)
    private LocalDateTime transactionDate;
}

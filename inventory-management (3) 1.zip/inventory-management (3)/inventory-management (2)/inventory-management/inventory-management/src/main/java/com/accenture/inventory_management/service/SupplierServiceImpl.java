package com.accenture.inventory_management.service;

import com.accenture.inventory_management.entity.Supplier;
import com.accenture.inventory_management.repository.SupplierRepository;
import com.accenture.inventory_management.service.SupplierService;
import org.springframework.stereotype.Service;

import java.util.List;

    @Service
    public class SupplierServiceImpl implements SupplierService {

        private final SupplierRepository repo;

        public SupplierServiceImpl(SupplierRepository repo) {
            this.repo = repo;
        }

        @Override public Supplier create(Supplier s) { return repo.save(s); }
        @Override public List<Supplier> getAll() { return repo.findAll(); }
        @Override public Supplier getById(Long id) {
            return repo.findById(id).orElseThrow(() -> new RuntimeException("Supplier not found"));
        }
        @Override public Supplier update(Long id, Supplier s) {
            Supplier cur = getById(id);
            cur.setCompanyName(s.getCompanyName());
            cur.setContactPerson(s.getContactPerson());
            cur.setEmail(s.getEmail());
            cur.setPhone(s.getPhone());
            return repo.save(cur);
        }
        @Override public void delete(Long id) { repo.deleteById(id); }


}

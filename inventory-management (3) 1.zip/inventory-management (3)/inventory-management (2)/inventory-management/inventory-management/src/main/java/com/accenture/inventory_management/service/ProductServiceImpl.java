package com.accenture.inventory_management.service;

import com.accenture.inventory_management.dto.ProductRequest;
import com.accenture.inventory_management.entity.Category;
import com.accenture.inventory_management.entity.Product;
import com.accenture.inventory_management.entity.Supplier;
import com.accenture.inventory_management.repository.CategoryRepository;
import com.accenture.inventory_management.repository.ProductRepository;
import com.accenture.inventory_management.repository.SupplierRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepo;
    private final CategoryRepository categoryRepo;
    private final SupplierRepository supplierRepo;

    // Constructor injection for testing
    public ProductServiceImpl(ProductRepository productRepo,
                              CategoryRepository categoryRepo,
                              SupplierRepository supplierRepo) {
        this.productRepo = productRepo;
        this.categoryRepo = categoryRepo;
        this.supplierRepo = supplierRepo;
    }

    @Override
    public List<Product> getAll() {
        return productRepo.findAll();
    }

    @Override
    public Product getById(Long id) {
        return productRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));
    }

    @Override
    public Product create(ProductRequest request) {
        Category category = categoryRepo.findById(request.getCategoryId())
                .orElseThrow(() -> new RuntimeException("Category not found with ID: " + request.getCategoryId()));

        Supplier supplier = supplierRepo.findById(request.getSupplierId())
                .orElseThrow(() -> new RuntimeException("Supplier not found with ID: " + request.getSupplierId()));

        Product product = new Product();
        product.setName(request.getName());
        product.setSku(request.getSku());
        product.setUnitPrice(request.getUnitPrice());
        product.setCurrentStock(request.getCurrentStock());
        product.setReorderLevel(request.getReorderLevel());
        product.setCategory(category);
        product.setSupplier(supplier);

        return productRepo.save(product);
    }

    @Override
    public Product update(Long id, ProductRequest request) {
        Product existing = getById(id);

        existing.setName(request.getName());
        existing.setSku(request.getSku());
        existing.setUnitPrice(request.getUnitPrice());
        existing.setCurrentStock(request.getCurrentStock());
        existing.setReorderLevel(request.getReorderLevel());

        Category category = categoryRepo.findById(request.getCategoryId())
                .orElseThrow(() -> new RuntimeException("Category not found"));
        existing.setCategory(category);

        Supplier supplier = supplierRepo.findById(request.getSupplierId())
                .orElseThrow(() -> new RuntimeException("Supplier not found"));
        existing.setSupplier(supplier);

        return productRepo.save(existing);
    }

    @Override
    public void delete(Long id) {
        Product product = getById(id);
        productRepo.delete(product);
    }

    @Override
    public List<Product> searchByName(String name) {
        return productRepo.findByNameContainingIgnoreCase(name);
    }

    @Override
    public List<Product> findLowStock() {
        return productRepo.findByCurrentStockLessThanEqual(50);
    }

    @Override
    public List<Product> getByCategory(Long categoryId) {
        return productRepo.findByCategoryId(categoryId);
    }

    @Override
    public List<Product> getBySupplier(Long supplierId) {
        return productRepo.findBySupplierId(supplierId);
    }

    @Override
    public List<Product> getLowStockProducts(int threshold) {
        return productRepo.findByCurrentStockLessThanEqual(threshold);
    }
}

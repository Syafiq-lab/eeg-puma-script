package com.accenture.inventory_management.service;

import com.accenture.inventory_management.entity.InventoryTransaction;
import com.accenture.inventory_management.entity.Product;
import com.accenture.inventory_management.repository.InventoryTransactionRepository;
import com.accenture.inventory_management.repository.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class InventoryTransactionImpl implements InventoryTransactionService {

    private final ProductRepository productRepo;
    private final InventoryTransactionRepository transactionRepo;

    public InventoryTransactionImpl(ProductRepository productRepo,
                                    InventoryTransactionRepository transactionRepo) {
        this.productRepo = productRepo;
        this.transactionRepo = transactionRepo;
    }

    @Override
    public InventoryTransaction stockIn(Long productId, int quantity) {
        if (quantity <= 0) throw new IllegalArgumentException("Quantity must be > 0");

        Product product = productRepo.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        product.setCurrentStock(product.getCurrentStock() + quantity);
        productRepo.save(product);

        InventoryTransaction tx = new InventoryTransaction();
        tx.setProduct(product);
        tx.setQuantity(quantity);
        tx.setTransactionType("IN");
        tx.setTransactionDate(LocalDateTime.now());

        return transactionRepo.save(tx);
    }

    @Override
    public InventoryTransaction stockOut(Long productId, int quantity) {
        if (quantity <= 0) throw new IllegalArgumentException("Quantity must be > 0");

        Product product = productRepo.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        if (product.getCurrentStock() < quantity) {
            throw new RuntimeException("Insufficient stock");
        }

        product.setCurrentStock(product.getCurrentStock() - quantity);
        productRepo.save(product);

        InventoryTransaction tx = new InventoryTransaction();
        tx.setProduct(product);
        tx.setQuantity(quantity);
        tx.setTransactionType("OUT");
        tx.setTransactionDate(LocalDateTime.now());

        return transactionRepo.save(tx);
    }

    @Override public List<InventoryTransaction> getAll() {
        return transactionRepo.findAll();
    }

    @Override public List<InventoryTransaction> getByProduct(Long productId) {
        return transactionRepo.findByProductProductId(productId);
    }


}


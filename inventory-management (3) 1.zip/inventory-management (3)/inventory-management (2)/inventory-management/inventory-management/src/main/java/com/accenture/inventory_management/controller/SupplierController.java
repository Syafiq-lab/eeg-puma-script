package com.accenture.inventory_management.controller;

import com.accenture.inventory_management.entity.Supplier;
import com.accenture.inventory_management.service.SupplierService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/supplier")
public class SupplierController {

    private final SupplierService service;

    public SupplierController(SupplierService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Supplier> create(@Valid @RequestBody Supplier supplier) {
        return new ResponseEntity<>(service.create(supplier), HttpStatus.CREATED);
    }

    @GetMapping
    public List<Supplier> getAll() { return service.getAll(); }

    @GetMapping("/{id}")
    public Supplier getById(@PathVariable Long id) { return service.getById(id); }

    @PutMapping("/{id}")
    public Supplier update(@PathVariable Long id, @Valid @RequestBody Supplier supplier) {
        return service.update(id, supplier);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}



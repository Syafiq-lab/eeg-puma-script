package com.accenture.inventory_management.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;

    public class ProductRequest {
        @NotBlank private String name;
        @NotBlank private String sku;
        @NotNull private BigDecimal unitPrice;
        @Min(0)  private int currentStock;
        @Min(0)  private int reorderLevel;
        @NotNull private Long categoryId;
        @NotNull private Long supplierId;

        // getters/setters
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getSku() { return sku; }
        public void setSku(String sku) { this.sku = sku; }
        public BigDecimal getUnitPrice() { return unitPrice; }
        public void setUnitPrice(BigDecimal unitPrice) { this.unitPrice = unitPrice; }
        public int getCurrentStock() { return currentStock; }
        public void setCurrentStock(int currentStock) { this.currentStock = currentStock; }
        public int getReorderLevel() { return reorderLevel; }
        public void setReorderLevel(int reorderLevel) { this.reorderLevel = reorderLevel; }
        public Long getCategoryId() { return categoryId; }
        public void setCategoryId(Long categoryId) { this.categoryId = categoryId; }
        public Long getSupplierId() { return supplierId; }
        public void setSupplierId(Long supplierId) { this.supplierId = supplierId; }
    }



package com.accenture.inventory_management.controller;

import com.accenture.inventory_management.dto.ProductRequest;
import com.accenture.inventory_management.entity.Product;
import com.accenture.inventory_management.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/product") //base url
public class ProductController {

    @Autowired
    private ProductService productService;

    // Create Product using ProductRequest DTO
    @PostMapping
    public ResponseEntity<Product> create(@RequestBody @Valid ProductRequest request) {
        return new ResponseEntity<>(productService.create(request), HttpStatus.CREATED);
    }

    @GetMapping
    public List<Product> getAll() {
        return productService.getAll();
    }

    @GetMapping("/{id}")
    public Product getById(@PathVariable Long id) {
        return productService.getById(id);
    }

    // Update Product using ProductRequest DTO
    @PutMapping("/{id}")
    public Product update(@PathVariable Long id, @RequestBody @Valid ProductRequest request) {
        return productService.update(id,request);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        productService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/search")
    public List<Product> search(@RequestParam String name) {
        return productService.searchByName(name);
    }

    @GetMapping("/low-stock")
    public List<Product> getLowStock() {
        return productService.findLowStock();
    }

    @GetMapping("/by-category/{categoryId}")
    public List<Product> getByCategory(@PathVariable Long categoryId) {
        return productService.getByCategory(categoryId);
    }

    @GetMapping("/by-supplier/{supplierId}")
    public List<Product> getBySupplier(@PathVariable Long supplierId) {
        return productService.getBySupplier(supplierId);
    }
}

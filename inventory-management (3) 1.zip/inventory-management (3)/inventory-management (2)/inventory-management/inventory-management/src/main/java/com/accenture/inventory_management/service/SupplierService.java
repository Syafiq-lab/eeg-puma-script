package com.accenture.inventory_management.service;

import com.accenture.inventory_management.entity.Supplier;
import java.util.List;

public interface SupplierService {
    Supplier create(Supplier supplier);
    List<Supplier> getAll();
    Supplier getById(Long id);
    Supplier update(Long id, Supplier supplier);
    void delete(Long id);
}


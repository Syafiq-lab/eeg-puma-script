package com.accenture.inventory_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class InventoryManagementApplicationTests {

        @Test
        void contextLoads() {
        }
}

package com.accenture.inventory_management.service;

import com.accenture.inventory_management.entity.Category;
import com.accenture.inventory_management.repository.CategoryRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CategoryServiceTest {

    @Mock
    private CategoryRepository categoryRepository;

    @InjectMocks
    private CategoryServiceImpl categoryService;

    private Category category;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        category = new Category(1L, "Cakes", "All kinds of cakes");
    }

    @Test
    void testSaveCategory() {
        when(categoryRepository.save(category)).thenReturn(category);

        Category saved = categoryService.saveCategory(category);

        assertNotNull(saved);
        assertEquals("Cakes", saved.getName());
        verify(categoryRepository, times(1)).save(category);
    }

    @Test
    void testGetAll() {
        when(categoryRepository.findAll()).thenReturn(Arrays.asList(category));

        List<Category> categories = categoryService.getAll();

        assertEquals(1, categories.size());
        assertEquals("Cakes", categories.get(0).getName());
        verify(categoryRepository, times(1)).findAll();
    }

    @Test
    void testGetById_Found() {
        when(categoryRepository.findById(1L)).thenReturn(Optional.of(category));

        Category found = categoryService.getById(1L);

        assertNotNull(found);
        assertEquals("Cakes", found.getName());
        verify(categoryRepository, times(1)).findById(1L);
    }

    @Test
    void testGetById_NotFound() {
        when(categoryRepository.findById(2L)).thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class, () -> categoryService.getById(2L));

        assertEquals("Category not found with ID: 2", ex.getMessage());
        verify(categoryRepository, times(1)).findById(2L);
    }

    @Test
    void testUpdateCategory() {
        Category updated = new Category(1L, "Pastries", "All kinds of pastries");

        when(categoryRepository.findById(1L)).thenReturn(Optional.of(category));
        when(categoryRepository.save(any(Category.class))).thenReturn(updated);

        Category result = categoryService.update(1L, updated);

        assertEquals("Pastries", result.getName());
        assertEquals("All kinds of pastries", result.getDescription());
        verify(categoryRepository, times(1)).findById(1L);
        verify(categoryRepository, times(1)).save(any(Category.class));
    }

    @Test
    void testDeleteCategory() {
        doNothing().when(categoryRepository).deleteById(1L);

        categoryService.delete(1L);

        verify(categoryRepository, times(1)).deleteById(1L);
    }

    @Test
    void testSearchByName() {
        when(categoryRepository.findByNameContainingIgnoreCase("cake"))
                .thenReturn(List.of(category));

        List<Category> result = categoryService.searchByName("cake");

        assertEquals(1, result.size());
        assertEquals("Cakes", result.get(0).getName());
        verify(categoryRepository, times(1))
                .findByNameContainingIgnoreCase("cake");
    }
}

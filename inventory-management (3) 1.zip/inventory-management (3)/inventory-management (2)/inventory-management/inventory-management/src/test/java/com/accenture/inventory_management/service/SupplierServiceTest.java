package com.accenture.inventory_management.service;

import com.accenture.inventory_management.entity.Supplier;
import com.accenture.inventory_management.repository.SupplierRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SupplierServiceTest {

    @Mock
    private SupplierRepository supplierRepository;

    @InjectMocks
    private SupplierServiceImpl supplierService;

    private Supplier supplier;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        supplier = new Supplier(1L, "Ordinary Baker", "Ali", "contact@ordinarybaker.com", "0123456789");
    }

    @Test
    void testCreateSupplier() {
        when(supplierRepository.save(any(Supplier.class))).thenReturn(supplier);

        Supplier created = supplierService.create(supplier);

        assertNotNull(created);
        assertEquals("Ordinary Baker", created.getCompanyName());
        verify(supplierRepository, times(1)).save(supplier);
    }

    @Test
    void testGetAllSuppliers() {
        when(supplierRepository.findAll()).thenReturn(Arrays.asList(supplier));

        List<Supplier> suppliers = supplierService.getAll();

        assertEquals(1, suppliers.size());
        assertEquals("Ordinary Baker", suppliers.get(0).getCompanyName());
        verify(supplierRepository, times(1)).findAll();
    }

    @Test
    void testGetSupplierById() {
        when(supplierRepository.findById(1L)).thenReturn(Optional.of(supplier));

        Supplier found = supplierService.getById(1L);

        assertNotNull(found);
        assertEquals("Ordinary Baker", found.getCompanyName());
        verify(supplierRepository, times(1)).findById(1L);
    }

    @Test
    void testUpdateSupplier() {
        Supplier updatedSupplier = new Supplier(1L, "Sweet Treats", "Aminah", "contact@sweettreats.com", "0198765432");

        when(supplierRepository.findById(1L)).thenReturn(Optional.of(supplier));
        when(supplierRepository.save(any(Supplier.class))).thenReturn(updatedSupplier);

        Supplier result = supplierService.update(1L, updatedSupplier);

        assertEquals("Sweet Treats", result.getCompanyName());
        assertEquals("contact@sweettreats.com", result.getEmail());
        verify(supplierRepository, times(1)).save(any(Supplier.class));
    }

    @Test
    void testDeleteSupplier() {
        doNothing().when(supplierRepository).deleteById(1L);

        supplierService.delete(1L);

        verify(supplierRepository, times(1)).deleteById(1L);
    }
}

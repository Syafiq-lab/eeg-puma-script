package com.accenture.inventory_management.controller;

import com.accenture.inventory_management.entity.InventoryTransaction;
import com.accenture.inventory_management.entity.Product;
import com.accenture.inventory_management.service.InventoryTransactionService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.Arrays;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(InventoryTransactionController.class)
class InventoryTransactionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private InventoryTransactionService transactionService;

    @Autowired
    private ObjectMapper objectMapper;

    private Product product;
    private InventoryTransaction txIn;
    private InventoryTransaction txOut;

    @BeforeEach
    void setUp() {
        product = new Product();
        product.setProductId(1L);
        product.setName("Laptop");
        product.setCurrentStock(10);

        txIn = new InventoryTransaction();
        txIn.setId(100L);
        txIn.setProduct(product);
        txIn.setQuantity(5);
        txIn.setTransactionType("IN");
        txIn.setTransactionDate(LocalDateTime.now());

        txOut = new InventoryTransaction();
        txOut.setId(101L);
        txOut.setProduct(product);
        txOut.setQuantity(3);
        txOut.setTransactionType("OUT");
        txOut.setTransactionDate(LocalDateTime.now());
    }

    @Test
    void testGetTransactionsByProduct() throws Exception {
        Mockito.when(transactionService.getTransactionsByProductId(1L))
                .thenReturn(Arrays.asList(txIn, txOut));

        mockMvc.perform(get("/api/inventory/product/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].transactionType", is("IN")))
                .andExpect(jsonPath("$[1].transactionType", is("OUT")));
    }

    @Test
    void testStockIn() throws Exception {
        Mockito.when(transactionService.stockIn(eq(1L), anyInt()))
                .thenReturn(txIn);

        mockMvc.perform(post("/api/inventory/stockin/1")
                        .param("quantity", "5")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.transactionType", is("IN")))
                .andExpect(jsonPath("$.quantity", is(5)));
    }

    @Test
    void testStockOut() throws Exception {
        Mockito.when(transactionService.stockOut(eq(1L), anyInt()))
                .thenReturn(txOut);

        mockMvc.perform(post("/api/inventory/stockout/1")
                        .param("quantity", "3")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.transactionType", is("OUT")))
                .andExpect(jsonPath("$.quantity", is(3)));
    }
}
